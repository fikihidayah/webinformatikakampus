<div class="bg-warning d-flex justify-content-end px-lg-5">
  <div class="top-head-container">
    <a href="https://uis.ac.id/" class="link-top-head">Universitas</a>
    <div class="link-top-head-separator"></div>
    <a href="" class="link-top-head">Fakultas</a>
    <div class="link-top-head-separator"></div>
    <a href="" class="link-top-head">UIS Gateway</a>
    <div class="link-top-head-separator"></div>
    <a href="" class="link-top-head">Admisi</a>
    <div class="link-top-head-separator"></div>
    <a href="" class="link-top-head">
      <img src="/web/assets/fonts/flags/indonesia.png" width="24" alt="">
    </a>
    <div class="link-top-head-separator"></div>
    <a href="" class="link-top-head">
      <img src="/web/assets/fonts/flags/united-kingdom.png" width="24" alt="">
    </a>
    <div class="link-top-head-separator"></div>
    <!-- image by : https://www.flaticon.com -->
  </div>
</div>
